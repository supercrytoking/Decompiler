## Code from various projects has been used, including but not limited to
* J-RET by WaterWolf
* JHexPane by Sam Koivu
* RSynaxPane by Robert Futrell
* Commons IO by Apache
* ASM by OW2
* FernFlower by Stiver
* Procyon by Mstrobel
* Luyten by DeathMarine
* CFR by Lee Benfield
* CFIDE by Bibl
* Smali by JesusFreke
* Dex2Jar by pxb1988 & Lanchon
* Krakatau by Storyyeller
* JD GUI/JD Core by The Java-Decompiler Team
* Enjarify by Storyyeller
* JADX by Skylot

## Contributors
[Full List Of Contributors](https://github.com/Konloch/bytecode-viewer/graphs/contributors)
* Konloch
* Bibl
* Fluke
* Righteous
* sahitya-pavurala
* priav03
* Afffsdd
* Szperak
* Zooty
* samczsun
* ItzSomebody
* DreamSworK
* HyperSpeeed
* If I missed you, please feel free to contact me @Konloch or konloch@gmail.com
