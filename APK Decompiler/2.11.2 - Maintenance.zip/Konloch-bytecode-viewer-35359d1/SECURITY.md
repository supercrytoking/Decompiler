# Security Policy

## Supported Versions

All versions of BCV are actively supported for security patches & updates.

## Reporting a Vulnerability

E-Mail konloch@gmail.com if you find any issues.
