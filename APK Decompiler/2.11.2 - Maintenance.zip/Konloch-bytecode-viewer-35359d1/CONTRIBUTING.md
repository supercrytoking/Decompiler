## Contribution Guide Lines/Coding Conventions
* Packages must start with the.bytecode.club.bytecodeviewer.
* All variables must be at the start of each class.