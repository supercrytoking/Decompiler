New User:
=========
Download and install Notepad++
Install java JDK & JRE
Download Android SDK, if the computer already exists Android Studio, you don't need to install the Android SDK manually.
Extract JvApkBuilder files and copy-paste manually this folders to drive C:\
Run Install for first time use..
Registration Online 



If error then..
Video tutorial ==> https://www.dropbox.com/sh/0oxcpry0qidfmo4/AAB7PxtSDiDgdmPy0ME0Z2kha?dl=0

If run Install.exe error you should setup the java JDK and JRE PATH mannualy . Next following the instruction on this link:
https://docs.oracle.com/javase/tutorial/essential/environment/paths.html
https://docs.oracle.com/goldengate/1212/gg-winux/GDRAD/java.htm#BGBFHBEA


Previous premium/free user:
===========================
Copy and paste file JvApkBuilder.exe to your installation (JvApkBuilder) folder for update manually!




support: B-Max Studio bjhulkmax@gmail.com
